{\rtf1\ansi\ansicpg1252\cocoartf1504\cocoasubrtf830
{\fonttbl\f0\fnil\fcharset0 HelveticaNeue;\f1\fnil\fcharset0 .AppleColorEmojiUI;}
{\colortbl;\red255\green255\blue255;\red53\green53\blue53;\red220\green161\blue13;}
{\*\expandedcolortbl;;\cssrgb\c27059\c27059\c27059;\cssrgb\c89412\c68627\c3922;}
\paperw11900\paperh16840\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab560
\pard\pardeftab560\slleading20\partightenfactor0

\f0\b\fs24 \cf2 Details:\
\
PINKRED
\b0  Colour: 
\b #DB5461
\b0 \

\b GREY
\b0  Colour: 
\b #30343F
\b0 \
Font used: 
\b Avenir
\b0 \
\
____________________________________\

\b HOW DOES THE CHALLENGE WORK?
\b0 \
..\
\pard\pardeftab560\slleading20\partightenfactor0

\f1 \cf2 1\uc0\u65039 \u8419 
\f0  
\b Main Objective: 
\b0 \
Build this layout with html & css as accurate as possible. It doesn\'92t matter how you approach it.\

\f1 2\uc0\u65039 \u8419 
\f0  
\b Bonus
\b0  : Make the site responsive.\

\f1 3\uc0\u65039 \u8419 
\f0  
\b Bonus
\b0 :  Add features like Animations. (For example: Visual number count on page load etc.)\
..\

\f1 \uc0\u55357 \u56481 
\f0 The goal is to 
\i challenge yourself
\i0  and to get familiar with building websites. It doesn\'92t matter if you weren\'92t able to finish the challenge, this isn\'92t a competition.\
\'85\

\f1 \uc0\u55357 \u56421 
\f0  Join the 
\b Slack group 
\b0 ({\field{\*\fldinst{HYPERLINK "http://webdevchallenges.slack.com"}}{\fldrslt \cf3 webdevchallenges.slack.com}}) in my Bio to support each other or ask for help when you\'92re stuck and need some advice.\
\'85\

\f1 \uc0\u55357 \u56567 
\f0  If you wanna update and document your progress on Instagram make sure to tag me and/or add the hashtag #webdevchallenges , so that I can see how you\'92re doing.\
\'85\
Feel free to share this post on your story, if you think that this might benefit others who want to become better at developing websites. #buildupdevs 
\f1 \uc0\u55357 \u56842 
\f0 \
\'85\
If you have any question, just drop a DM! Wish you guys all the best building the website!! 
\f1 \uc0\u55357 \u56836 
\f0 \
}